package com.example.emailsender

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.emailsender.ui.theme.EmailSenderTheme

class EmailCatcher : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()



        setContent {
            EmailSenderTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    val subj by remember { mutableStateOf({
                        val data = intent.data
                        if(data == null){
                            return@mutableStateOf ""
                        }


                        return@mutableStateOf intent.getStringExtra(Intent.EXTRA_SUBJECT)

                    }()) }
                    Greeting(
                        name = subj!!,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }


}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    EmailSenderTheme {
        Greeting("Android")
    }
}
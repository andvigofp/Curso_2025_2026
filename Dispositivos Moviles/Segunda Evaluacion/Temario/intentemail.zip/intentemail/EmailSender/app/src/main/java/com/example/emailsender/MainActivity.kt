package com.example.emailsender

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.emailsender.ui.theme.EmailSenderTheme
import androidx.core.net.toUri

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme {
                EmailButton(
                    onSendEmail = {
                        // Construimos el intent para abrir la app de correo
                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                            data = "mailto:".toUri() // Garantiza que solo apps de correo lo manejen
                            putExtra(Intent.EXTRA_EMAIL, arrayOf("destinatario@ejemplo.com"))
                            putExtra(Intent.EXTRA_SUBJECT, "Asunto del correo")
                            putExtra(Intent.EXTRA_TEXT, "Hola,\nEste es el contenido del correo.")
                        }

                        // Verifica que exista una app de correo instalada
                        if (intent.resolveActivity(packageManager) != null) {
                            startActivity(intent)
                        }
                    }
                )
            }
        }
    }
}

@Composable
fun EmailButton(onSendEmail: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center
    ) {
        Button(
            onClick = onSendEmail,
            modifier = Modifier.padding(20.dp)
        ) {
            Text("Enviar correo")
        }
    }
}
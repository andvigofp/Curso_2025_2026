package org.example.Repositorios;

import org.example.Entidades.Habilidad;
import org.example.Entidades.Personaje;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class HabilidadRepositorio implements Repositorio<Habilidad>{
    private Session session;

    public HabilidadRepositorio(Session session) {
        this.session = session;
    }

    @Override
    public void guardar(Habilidad habilidad) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();
            session.persist(habilidad);
            trx.commit();
        }catch (Exception e) {
            System.out.println("Error al guardar: " + e.toString());
        }
    }

    //Método para crear la habilidad
    public void crearHabilidad(String nombre, String descripcion) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();

            // 1. Verificar si ya existe una habilidad con ese nombre
            Habilidad existente = session.createQuery(
                            "from Habilidad h where h.nombre = :nombre", Habilidad.class)
                    .setParameter("nombre", nombre)
                    .uniqueResult();

            if (existente != null) {
                System.out.println("Ya existe una habilidad con ese nombre: " + nombre);
                return;
            }

            //2. Obtener el nuevo ID para el personaje
            Integer maxIdHabilidad = (Integer) session.createQuery(
                    "SELECT MAX(h.id) FROM Habilidad h").uniqueResult();
            int nuevoIdHabilidad = (maxIdHabilidad == null ? 1 : maxIdHabilidad + 1);

            //3. Crear la habilidad
            Habilidad habilidad = new Habilidad(nuevoIdHabilidad, nombre, descripcion);

            //Persistir la habilidad
            session.persist(habilidad);

            trx.commit();
            System.out.println("La habilidad se a insertado exitosamente.");
        }catch (Exception e) {
            System.out.println("Error al crear una habilidad:  " + e.toString());
        }
    }

    //Método para eliminar una habilidad por su nombre
    public void borrarHabilidad(String nombre) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();

            Habilidad habilidad = session.createQuery(
                    "select h from Habilidad h where h.nombre = :nombre", Habilidad.class)
                    .setParameter("nombre", nombre)
                    .uniqueResult();

            if (habilidad == null) {
                System.out.println("No existe esa habilidad con ese nombre: " + nombre);
                return;
            }


            //1. Limpiar la tabla intermedia entre habilidad y personaje (Personaje_Habilidad)
            for (Personaje personaje : habilidad.getListaPersonajes()) {
                personaje.getListaHabilidades().remove(habilidad);
            }

            //2. Limpiar la lista de personajes (ManyToMany)
            habilidad.getListaPersonajes().clear();
            session.flush();

            //2. Eliminar la habilidad
            session.remove(habilidad);

            trx.commit();
            System.out.println("Se a eliminado la habilidad exitosamente.");
        }catch (Exception e) {
            if(trx !=null) trx.rollback();
            System.out.println("Error al eliminar la habilidad: " + e.getMessage());
        }
    }

    //Método para actulizar la habilidad;
    public void actualizarHabilidad(int id, String nombre, String descripcion) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();

            // 1. Buscar la habilidad por ID
            Habilidad habilidad = session.createQuery(
                    "select h from Habilidad h where h.id = :id", Habilidad.class)
                    .setParameter("id", id)
                    .uniqueResult();

            if (habilidad == null) {
                System.out.println("No existe esa habilidad con esa id: " + id);
                return;
            }

            // 2. Comprobar si ya existe otra habilidad con ese nombre
            Habilidad habilidadExistente = session.createQuery(
                            "from Habilidad h where h.nombre = :nombre and h.id != :id", Habilidad.class)
                    .setParameter("nombre", nombre)
                    .setParameter("id", id)
                    .uniqueResult();

            if (habilidadExistente != null) {
                System.out.println("Ya existe otra habilidad con ese nombre: " + nombre);
                return;
            }

            habilidad.setNombre(nombre);
            habilidad.setNombre(descripcion);

            session.merge(habilidad);

            trx.commit();
            System.out.println("Se a actualizado la habilidad exitosamente.");
        }catch (Exception e) {
            if (trx !=null) trx.rollback();
            System.out.println("Error al actualidad la habilidad: " + e.getMessage());
        }
    }

    public void asignarHabilidaPersonaje(String nombrePersonaje, String nombreHabilidad) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();

            //1. Buscar el personaje por nombre
            Personaje personaje = session.createQuery(
                    "from Personaje p where p.nombre = :nombre", Personaje.class)
                    .setParameter("nombre", nombrePersonaje)
                    .uniqueResult();

            if (personaje == null) {
                System.out.println("No existe ese personaje con ese nombre: " + nombrePersonaje);
                return;
            }

            //2. Buscar la Habilidad por su nombre
            Habilidad habilidad = session.createQuery(
                    "from Habilidad h where h.nombre = :nombre", Habilidad.class)
                    .setParameter("nombre", nombreHabilidad)
                    .uniqueResult();

            if (habilidad == null) {
                System.out.println("No existe esa habilidad con ese nombre: " + nombreHabilidad);
            }

            //3. Verificar si ya está asignado la habilidad al personaje
            if (personaje.getListaHabilidades().contains(habilidad)) {
                System.out.println("El personaje ya tiene esa habilidad asignada.");
                return;
            }

            //4. Asignar la habilidad al personaje (bidireccional)
            personaje.addHabilidad(habilidad);

            //5. Guardar los cambios
            session.merge(personaje);

            trx.commit();
            System.out.println("Habilidad asignada correctamente al personaje.");
        }catch (Exception e) {
            if (trx !=null) trx.rollback();
            System.out.println("Error al asignar la habilidad: " + e.getMessage());
        }
    }
}

package org.example.Repositorios;

import org.example.Entidades.Personaje;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import java.util.List;

public class PersonajeRepositorio implements Repositorio<Personaje> {
    private Session session;

    public PersonajeRepositorio(Session session) {
        this.session = session;
    }

    @Override
    public void guardar(Personaje personaje) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();
            session.persist(personaje);
            trx.commit();
        }catch (Exception e) {
            System.out.println("Error al guardar: " + e.toString());
        }
    }

    //Método para crear el personaje
    public void crearPersonaje(String nombre, String alias) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();

            //1. Verificar si ya existe un personaje con ese nombre
            Personaje existente = session.createQuery(
                            "from Personaje p where p.nombre = :nombre", Personaje.class)
                    .setParameter("nombre", nombre)
                    .uniqueResult();

            if (existente != null) {
                System.out.println("Ya existe un personaje con ese nombre: " + nombre);
                return;
            }

            //2. Obtener el nuevo ID para el personaje
            Integer maxIdPersonaje = (Integer) session.createQuery(
                    "SELECT MAX(p.id) FROM Personaje p").uniqueResult();
            int nuevoIdPersonaje = (maxIdPersonaje == null ? 1 : maxIdPersonaje + 1);

            //3. Crear el personaje
            Personaje personaje = new Personaje(nuevoIdPersonaje,nombre, alias);

            //Persistir el traje
            session.persist(personaje);

            trx.commit();
            System.out.println("Personaje creado exitosamente.");

        } catch (Exception e) {
            if (trx != null) trx.rollback();
            System.out.println("Error al insertar un personaje: " + e.getMessage());
        }
    }

    //Método para borrar el personaje por id
    public void borrarPersonaje(int id) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();

            // Obtener el personaje
            Personaje personaje = session.createQuery(
                            "FROM Personaje p WHERE p.id = :id", Personaje.class)
                    .setParameter("id", id)
                    .uniqueResult();

            if (personaje == null) {
                System.out.println("No existe un personaje con ese ID.");
                return;
            }

            // 1. Borrar participaciones asociadas (tabla Participa)
            Query<?> q1 = session.createQuery("DELETE FROM Participa p WHERE p.personaje.id = :id");
            q1.setParameter("id", id).executeUpdate();

            // 2. Limpiar la lista de habilidades (ManyToMany)
            personaje.getListaHabilidades().clear();
            session.flush();

            // 3. Quitar la relación con el traje (OneToOne)
            if (personaje.getTraje() != null) {
                personaje.setTraje(null);
            }

            // 4. Borrar el personaje
            session.remove(personaje);

            trx.commit();
            System.out.println("Personaje borrado exitosamente.");

        } catch (Exception e) {
            if (trx != null) trx.rollback();
            System.out.println("Error al borrar el personaje: " + e.getMessage());
        }
    }

    //Método para actualizar un personaje
    public void actualizarPersonaje(int id, String nombre, String alias) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();

            //1. Obtener el personaje por ID
            Personaje personaje = session.createQuery("select p from Personaje p where p.id = :id", Personaje.class)
                    .setParameter("id", id)
                    .uniqueResult();

            if (personaje ==null) {
                System.out.println("No existe un personaje con esa ID: " + id);
                return;
            }

            //2. Verificar si ya existe otro personaje con ese nombre
            Personaje personajeExistente = session.createQuery(
                            "from Personaje p where p.nombre = :nombre and p.id != :id", Personaje.class)
                    .setParameter("nombre", nombre)
                    .setParameter("id", id)
                    .uniqueResult();

            if (personajeExistente != null) {
                System.out.println("Ya existe otro personaje con ese nombre: " + nombre);
                return;
            }

            // Actualizar campos
            personaje.setNombre(nombre);
            personaje.setAlias(alias);

            session.merge(personaje);

            trx.commit();
            System.out.println("Personaje actualizado correctamente.");

        }catch (Exception e) {
            if (trx !=null) trx.rollback();
            System.out.println("Error al actualizar el personaje: " + e.getMessage());
        }
    }

    //Método para Mostrar los datos de un personaje (id, nombre, alias, traje, habilidades,
    //eventos en los que ha participado con su rol y fecha).
    public Personaje mostrarDatosPersonaje(int id) {
        try {
            //1. Cargar personaje + traje
            Personaje personaje = session.createQuery(
                            "SELECT p FROM Personaje p " +
                                    "LEFT JOIN FETCH p.traje t " +
                                    "WHERE p.id = :id", Personaje.class)
                    .setParameter("id", id)
                    .uniqueResult();

            if (personaje == null) {
                System.out.println("No existe un personaje con ese ID");
                return null;
            }

            //2. Cargar habilidades (2da consulta automática)
            personaje.getListaHabilidades().size();

            //3. Cargar participaciones + eventos
            personaje.getListaParticipantes().forEach(pa -> {
                if (pa.getEvento() != null) pa.getEvento().getNombre();
            });

            //Mostrar datos
            System.out.println("ID: " + personaje.getId());
            System.out.println("Nombre: " + personaje.getNombre());
            System.out.println("Alias: " + personaje.getAlias());

            if (personaje.getTraje() != null) {
                System.out.println("Traje: " + personaje.getTraje().getEspecificacion());
            }

            System.out.println("\nHabilidades:");
            personaje.getListaHabilidades().forEach(
                    h -> System.out.println(" - " + h.getNombre())
            );

            //Mostrar datos
            System.out.println("\nParticipaciones en eventos:");
            personaje.getListaParticipantes().forEach(pa -> {
                System.out.println("Evento: " + pa.getEvento().getNombre());
                System.out.println("Lugar: " + pa.getEvento().getLugar());
                System.out.println("Rol: " + pa.getRol());
                System.out.println("Fecha: " + pa.getFecha());
                System.out.println("---");
            });

            return personaje;

        } catch (Exception e) {
            System.out.println("Error al obtener datos del personaje: " + e.getMessage());
            return null;
        }
    }

    public List<Personaje> mostrarPersonajePorEvento(String nombreEveneto) {
        try {
            List<Personaje> personajes = session.createQuery("" +
                    "select distinct p from Personaje p " +
                    "inner join p.listaParticipantes pa " +
                    "inner join pa.evento e " +
                    "where e.nombre = : nombreEvento", Personaje.class)
                    .setParameter("nombreEvento", nombreEveneto)
                    .list();

            for (Personaje p : personajes) {
                System.out.println("- " + p.getNombre() + " (" + p.getAlias() + ")");

                p.getListaParticipantes().forEach(pa -> {
                    if (pa.getEvento().getNombre().equals(nombreEveneto)) {
                        System.out.println("Rol: " + pa.getRol());
                        System.out.println("Fecha: " + pa.getFecha());
                    }
                });
            }
            return personajes;
        }catch (Exception e) {
            System.out.println("Error al buscar personajes por evento: " + e.getMessage());
            return List.of();
        }
    }

    public long contarPersonajesPorHabilidad(String nombreHabilidad) {
        try {
            Long cantidad =  session.createQuery(
                            "SELECT COUNT(p) FROM Personaje p " +
                                    "JOIN p.listaHabilidades h " +
                                    "WHERE h.nombre = :nombreHabilidad", Long.class)
                    .setParameter("nombreHabilidad", nombreHabilidad)
                    .uniqueResult();

            System.out.println("Cantidad de personajes con la habilidad '" + nombreHabilidad + "': " + cantidad);
            return cantidad;

        } catch (Exception e) {
            System.out.println("Error al contar personajes por habilidad: " + e.getMessage());
            return 0;
        }
    }
}
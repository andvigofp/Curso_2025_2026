package org.example.Entidades;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor

@Table(name = "Traje")
public class Traje {
    @Id
    private int id;

    //NotNull
    @Column(nullable = false,  unique = true)
    private String  especificacion;


    @OneToOne(mappedBy = "traje")
    private Personaje personaje;


    public Traje(int id, String especialidad) {
        this.id = id;
        this.especificacion = especialidad;
    }
}

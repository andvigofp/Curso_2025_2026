package org.example.Entidades;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor

@Table(name = "Personaje")
public class Personaje {
    @Id
    private int id;

    //NotNull
    @Column(nullable = false,  unique = true)
    private String nombre;
    private String alias;

    @OneToOne
    @JoinColumn(name = "id_traje", unique = true)
    private Traje traje;


    @ManyToMany
    @JoinTable(
            name = "Personaje_Habilidad",
            joinColumns = @JoinColumn(name = "id_personaje"),
            inverseJoinColumns = @JoinColumn(name = "id_habilidad")

    )
    private List<Habilidad> listaHabilidades = new ArrayList<>();

    @OneToMany(mappedBy = "personaje")
    private List<Participa> listaParticipantes = new ArrayList<>();


    public Personaje(int id, String nombre, String alias) {
        this.id = id;
        this.nombre = nombre;
        this.alias = alias;
    }


    // MÉTODOS RELACIONES BIDIRECCIONALES
    public void addHabilidad(Habilidad habilidad) {
        listaHabilidades.add(habilidad);
        habilidad.getListaPersonajes().add(this);
    }

    public void addParticipacion(Participa participa) {
        listaParticipantes.add(participa);
        participa.setPersonaje(this);
    }
}

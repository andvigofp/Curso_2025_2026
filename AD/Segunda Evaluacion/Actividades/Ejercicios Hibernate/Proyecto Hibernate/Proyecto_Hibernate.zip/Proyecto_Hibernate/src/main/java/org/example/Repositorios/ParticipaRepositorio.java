package org.example.Repositorios;

import org.example.Entidades.Evento;
import org.example.Entidades.Participa;
import org.example.Entidades.ParticipaPK;
import org.example.Entidades.Personaje;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.time.LocalDate;

public class ParticipaRepositorio implements Repositorio<Participa>{
    private Session session;

    public ParticipaRepositorio(Session session) {
        this.session = session;
    }

    @Override
    public void guardar(Participa participa) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();
            session.persist(participa);
            trx.commit();
        }catch (Exception e) {
            System.out.println("Error al guardar: " + e.toString());
        }
    }


}

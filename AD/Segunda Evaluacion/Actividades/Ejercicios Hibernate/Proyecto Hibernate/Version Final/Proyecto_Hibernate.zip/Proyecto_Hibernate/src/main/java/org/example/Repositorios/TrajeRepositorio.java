package org.example.Repositorios;

import org.example.Entidades.Personaje;
import org.example.Entidades.Traje;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class TrajeRepositorio implements Repositorio<Traje>{
    private Session session;

    public TrajeRepositorio(Session session) {
        this.session = session;
    }

    @Override
    public void guardar(Traje traje) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();
            session.persist(traje);
            trx.commit();
        }catch (Exception e) {
            System.out.println("Error al guardar: " + e.toString());
        }
    }

    //Método para cambiar de traje a un personaje y crear el traje
    public void cambiarTraje(String nombrePersonaje, String nuevaEspecificacion) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();

            //1. Buscar personaje por nombre
            Personaje personaje = session.createQuery(
                            "from Personaje p where p.nombre = :nombre", Personaje.class)
                    .setParameter("nombre", nombrePersonaje)
                    .uniqueResult();

            if (personaje == null) {
                System.out.println("No existe un personaje con ese nombre: " + nombrePersonaje);
                return;
            }

            // 2. Verificar si existe ya un traje con esa especificación
            Traje trajeExistente = session.createQuery(
                            "from Traje t where t.especificacion = :especificacion", Traje.class)
                    .setParameter("especificacion", nuevaEspecificacion)
                    .uniqueResult();

            if (trajeExistente != null) {
                System.out.println("Ya existe un traje con esa especificación. Debe ser único." + nuevaEspecificacion);
                return;
            }

            //3. Obtener nuevo ID para el traje
            Integer maxIdTraje = (Integer) session.createQuery(
                    "SELECT MAX(t.id) FROM Traje t").uniqueResult();
            int nuevoIdTraje = maxIdTraje + 1;

            //4. Crear nuevo traje
            Traje nuevoTraje = new Traje(nuevoIdTraje, nuevaEspecificacion);

            //5. Desasociar el traje antiguo si existe
            Traje trajeAntiguo = personaje.getTraje();
            if (trajeAntiguo != null) {
                personaje.setTraje(null);
                trajeAntiguo.setPersonaje(null);
            }

            //6. Asociar el nuevo traje al personaje (bidireccional)
            personaje.setTraje(nuevoTraje);
            nuevoTraje.setPersonaje(personaje);

            //7. Persistir el nuevo traje
            session.persist(nuevoTraje);

            trx.commit();
            System.out.println("Traje cambiado exitosamente.");
            System.out.println("-----------------------------------");
            System.out.println("ID Personaje: " + personaje.getId());
            System.out.println("Nombre Personaje: " + personaje.getNombre());
            System.out.println("ID Traje: " + personaje.getTraje().getId());
            System.out.println("Especificación: " + personaje.getTraje().getEspecificacion());
            System.out.println("------------------------------------");

        } catch (Exception e) {
            if (trx != null) trx.rollback();
            System.out.println("Error al cambiar el traje: " + e.getMessage());
        }
    }
}

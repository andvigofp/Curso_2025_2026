package org.example;

import org.example.Aplicacion.MEJMetodos;
import org.example.Repositorios.*;
import org.hibernate.Session;

public class App {
    public static void main(String[] args) {
        System.out.println("Test");

        Session session = HibernateUtil.get().openSession();

        PersonajeRepositorio personajeRepositorio = new PersonajeRepositorio(session);
        HabilidadRepositorio habilidadRepositorio = new HabilidadRepositorio(session);
        EventoRepositorio eventoRepositorio  = new EventoRepositorio(session);
        TrajeRepositorio trajeRepositorio = new TrajeRepositorio(session);

        MEJMetodos metodos = new MEJMetodos(personajeRepositorio, habilidadRepositorio, eventoRepositorio, trajeRepositorio);

        metodos.mostrarMenu();

        session.close();
        System.out.println("Finalizando la conexion a MySQL");
    }
}

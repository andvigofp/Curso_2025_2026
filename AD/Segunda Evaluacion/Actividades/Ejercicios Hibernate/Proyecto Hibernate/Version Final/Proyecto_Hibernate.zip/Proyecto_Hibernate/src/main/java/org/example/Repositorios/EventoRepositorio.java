package org.example.Repositorios;

import org.example.Entidades.Evento;
import org.example.Entidades.Participa;
import org.example.Entidades.ParticipaPK;
import org.example.Entidades.Personaje;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.time.LocalDate;

public class EventoRepositorio implements Repositorio<Evento> {
    private Session session;

    public EventoRepositorio(Session session) {
        this.session = session;
    }

    @Override
    public void guardar(Evento evento) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();
            session.persist(evento);
            trx.commit();
        }catch (Exception e) {
            System.out.println("Error al guardar: " + e.toString());
        }
    }

    //Método para registrar la participación del personaje en evento
    public void registarParticionEvento(String nombrePersonaje, String nombreEvento, String rol, String fecha) {
        Transaction trx = null;

        try {
            trx = session.beginTransaction();

            //1. Buscar personaje por nombre
            Personaje personaje = session.createQuery("" +
                            "from Personaje p where p.nombre = :nombre", Personaje.class)
                    .setParameter("nombre", nombrePersonaje)
                    .uniqueResult();

            if (personaje == null) {
                System.out.println("No existe un personaje con ese nombre: " + nombrePersonaje);
                if (trx !=null) trx.rollback();
                return;
            }

            //2. Buscar evento por nombre
            Evento evento = session.createQuery("" +
                            "from Evento e where e.nombre = :nombre", Evento.class)
                    .setParameter("nombre", nombreEvento)
                    .uniqueResult();

            if (evento == null) {
                System.out.println("No existe un evento con ese nombre: " + nombreEvento);
                if (trx !=null) trx.rollback();
                return;
            }

            //3. Comprobar si ya existe participación previa
            Participa existente = session.createQuery("" +
                            "from Participa p where p.personaje.id = :idPersonaje and p.evento.id = :idEvento", Participa.class)
                    .setParameter("idPersonaje", personaje.getId())
                    .setParameter("idEvento", evento.getId())
                    .uniqueResult();

            if (existente !=null) {
                System.out.println("Ese personaje ya tiene registrada participación en ese evento.");
                return;
            }

            //4. Crear la clave primaria compuesta
            ParticipaPK participaPK = new ParticipaPK(personaje.getId(), evento.getId());

            //5. Convertir la fecha
            LocalDate fechaFormateada = LocalDate.parse(fecha);

            //6. Crear la participación
            Participa participa = new Participa(participaPK, personaje, evento, fechaFormateada, rol);

            //7. Relaciones bidireccionales
            personaje.addParticipacion(participa);
            evento.addParticipacion(participa);

            //8. Guardar
            session.persist(participa);

            trx.commit();
            System.out.println("Participación registrada correctamente.");
            System.out.println("-----------------------------");
            System.out.println("ID Participa: " + participa.getId());
            System.out.println("Nombre Personaje: " + participa.getPersonaje().getNombre());
            System.out.println("Nombre Evento: " + participa.getEvento().getNombre());
            System.out.println("Rol: " + participa.getRol());
            System.out.println("Fecha: " + participa.getFecha());

        }catch (Exception e) {
            if (trx !=null) trx.rollback();
            System.out.println("Error al registrar participación: " + e.getMessage());
        }
    }
}

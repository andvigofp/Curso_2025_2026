package org.example.Entidades;

import jakarta.persistence.*;
import lombok.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor

@Table(name = "Habilidad")
public class Habilidad {
    @Id
    private int id;

    //NotNull
    @Column(nullable = false,  unique = true)
    private String nombre;

    private String descripcion;

    @ManyToMany(mappedBy = "listaHabilidades", fetch = FetchType.LAZY) // coincide con Personaje
    private List<Personaje> listaPersonajes = new ArrayList<>();

    public Habilidad(int id, String nombre, String descripcion) {
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }
}

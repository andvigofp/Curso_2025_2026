package org.example.Aplicacion;

import org.example.Repositorios.*;

import java.util.Scanner;

public class MEJMetodos {
    private static Scanner teclado = new Scanner(System.in);
    private PersonajeRepositorio personajeRepositorio;
    private HabilidadRepositorio habilidadRepositorio;
    private EventoRepositorio eventoRepositorio;
    private TrajeRepositorio trajeRepositorio;

    public MEJMetodos(PersonajeRepositorio personajeRepositorio, HabilidadRepositorio habilidadRepositorio, EventoRepositorio eventoRepositorio, TrajeRepositorio trajeRepositorio) {
        this.personajeRepositorio = personajeRepositorio;
        this.habilidadRepositorio = habilidadRepositorio;
        this.eventoRepositorio = eventoRepositorio;
        this.trajeRepositorio = trajeRepositorio;
    }

    public void mostrarMenu() {
        int opcion = -1;

        do {
            System.out.println(
                    "1. Crear nuevo personaje\n" +
                            "2. Borrar personaje por ID\n" +
                            "3. Modificar personaje (nombre y alias)\n" +
                            "4. Crear nueva habilidad\n" +
                            "5. Borrar habilidad por nombre\n" +
                            "6. Modificar habilidad (nombre y descripción)\n" +
                            "7. Asignar habilidad a un personaje (por nombre de personaje y habilidad)\n" +
                            "8. Registrar participación de un personaje en un evento (nombre del personaje, nombre del evento, rol y fecha)\n" +
                            "9. Cambiar el traje de un personaje (nombre del personaje y especificación del nuevo traje)\n" +
                            "10. Mostrar los datos completos de un personaje (id, nombre, alias, traje, habilidades, eventos con rol y fecha)\n" +
                            "11. Mostrar los personajes que participaron en un evento determinado\n" +
                            "12. Mostrar cuántos personajes tienen una habilidad concreta\n" +
                            "13. Salir"
            );

            opcion = teclado.nextInt();
            teclado.nextLine();

            switch (opcion) {
                case 1:
                    String nombrePersonaje = pedirString("Introduce el nombre del personaje a insertar: ");
                    String aliasPeronsaje = pedirString("Introduce el alias del personaje a insertar: ");

                    personajeRepositorio.crearPersonaje(nombrePersonaje, aliasPeronsaje);
                    break;
                case 2:
                    int idPersonaje = pedirInt("Introduce la id del personaje a eliminar: ");

                    personajeRepositorio.borrarPersonaje(idPersonaje);
                    break;
                case 3:
                    int iDPersonaje = pedirInt("introduce la id personaje: ");
                    teclado.nextLine();
                    String nuevoPersonaje = pedirString("Introduce el nombre del personaje a actualizar: ");
                    String nuevoAlias = pedirString("Introduce el alias del personaje a actualizar: ");

                    personajeRepositorio.actualizarPersonaje(iDPersonaje, nuevoPersonaje, nuevoAlias);
                    break;
                case 4:
                    String nombreHabilidad = pedirString("Introduce el nombre de la habilidad a insertar: ");
                    String descripcionHabilidad = pedirString("Introduce la descripción de la habilidad a insertar: ");

                    habilidadRepositorio.crearHabilidad(nombreHabilidad, descripcionHabilidad);
                    break;
                case 5:
                    String nombreHabilidadEliminar = pedirString("Introduce el nombre de la habilidad a eliminar: ");

                    habilidadRepositorio.borrarHabilidad(nombreHabilidadEliminar);
                    break;
                case 6:
                    int idHabilidad = pedirInt("Introduce la id de la habilidad existente: ");
                    teclado.nextLine();

                    String nuevoNombreHabilidad = pedirString("Introduce la habilidad a modificar: ");
                    String nuevaDescripcionHabilidad = pedirString("Introduce la descripción a modificar: ");

                    habilidadRepositorio.actualizarHabilidad(idHabilidad, nuevoNombreHabilidad, nuevaDescripcionHabilidad);
                    break;
                case 7:
                    String nombrePersonajeAsinar = pedirString("Introduce el nombre del personaje existente a asignar: ");
                    String nombreHabilidadAsignar = pedirString("Introduce el nombre de la habilidad a asignar: ");

                    habilidadRepositorio.asignarHabilidaPersonaje(nombrePersonajeAsinar, nombreHabilidadAsignar);
                    break;
                case 8:
                    String nombrePersonajeParticipa = pedirString("Introduce el nombre del persona a participar: ");
                    String nombreEventoParticipa = pedirString("Introduce el nombre del evento a participar: ");
                    String rol = pedirString("Introduce el rol a participar: ");
                    String fecha = pedirString("Introduce la fecha de participan (2000-01-12): ");

                    eventoRepositorio.registarParticionEvento(nombrePersonajeParticipa, nombreEventoParticipa, rol, fecha);
                    break;
                case 9:
                    String nombrePersonajeExistente = pedirString("Introduce el nombre personaje existente: ");
                    String nuevaEspecificacion = pedirString("Introduce la nuevaEspecificación del traje: ");

                    trajeRepositorio.cambiarTraje(nombrePersonajeExistente, nuevaEspecificacion);
                    break;
                case 10:
                    String nombrePersonajeMostrar = pedirString("Introduce el nombre de la persona para mostrar sus datos: ");

                    personajeRepositorio.mostrarDatosPersonaje(nombrePersonajeMostrar);
                    break;
                case 11:
                    String nombreEvento = pedirString("Introduce el nombre de evento para mostrar datos del personaje: ");

                    personajeRepositorio.mostrarPersonajePorEvento(nombreEvento);
                    break;
                case 12:
                    String nombreHabilidadMostrar = pedirString("Introduce la habilidad para mostrar cuantos peron sajes usa esa habilidad :");

                    personajeRepositorio.mostrarPersonajeHabilidad(nombreHabilidadMostrar);
                    break;
                case 13:
                    System.out.println("Fin del programa");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Error: Solo puedes elegir entre las opciones entre (1-13)");

            }
        }while (opcion != 17);
    }

    public static int pedirInt(String string) {
        System.out.println(string);
        while (!teclado.hasNextInt()) {
            System.out.println("Debe ser un número entero.");
            teclado.next(); // limpiar entrada incorrecta
        }
        return teclado.nextInt();
    }


    public static String pedirString(String string) {
        System.out.println(string);
        return teclado.nextLine();
    }
}

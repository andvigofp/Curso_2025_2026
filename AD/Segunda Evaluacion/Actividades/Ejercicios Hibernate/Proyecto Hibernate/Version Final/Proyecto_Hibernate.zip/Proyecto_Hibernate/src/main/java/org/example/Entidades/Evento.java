package org.example.Entidades;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor

@Table(name = "Evento")
public class Evento {
    @Id
    private int id;

    //NotNull
    @Column(nullable = false,  unique = true)
    private String nombre;

    private String lugar;

    @OneToMany(mappedBy = "evento", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    private List<Participa> listaParticipantes = new ArrayList<>();

    public Evento(int id, String nombre, String lugar) {
        this.id = id;
        this.nombre = nombre;
        this.lugar = lugar;
    }

    // MÉTODO BIDIRECCIONAL
    public void addParticipacion(Participa participa) {
        listaParticipantes.add(participa);
        participa.setEvento(this);
    }
}
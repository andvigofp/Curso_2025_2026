package org.example.Entidades;

import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.Objects;

@Embeddable
@NoArgsConstructor
@AllArgsConstructor
public class ParticipaPK implements Serializable {

    private int idPersonaje;
    private int idEvento;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ParticipaPK that = (ParticipaPK) o;
        return idPersonaje == that.idPersonaje &&
                idEvento == that.idEvento;
    }

    @Override
    public int hashCode() {
        return Objects.hash(idPersonaje, idEvento);
    }
}